package com.cts.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

}